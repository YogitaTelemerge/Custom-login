<?php
/**
 * Plugin Name: Admin URL customization
 * Description:  changes admin URL according to plugin
 * Version: 1.0
 * Author: Yogita Rathi
 */
ini_set('display_errors','Off'); 

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

// Add a custom settings page.
function custom_admin_url_page() {

    add_options_page(
        'Custom Admin URL',
        'new URL',
        'manage_options',
        'custom-admin-url',
        'custom_admin_url_page_content'
    );
}
add_action('admin_menu', 'custom_admin_url_page');

// Register plugin settings.
function custom_admin_url_init() {
    register_setting('custom_admin_url_group', 'custom_admin_url');
}
add_action('admin_init', 'custom_admin_url_init');

// Create the settings page content.
function custom_admin_url_page_content() {
    ?>
    <div class="wrap">
        <h2>Admin URL Settings</h2>
        <form method="post" action="options.php">
            <?php
            settings_fields('custom_admin_url_group');
            do_settings_sections('custom-admin-url');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Custom Admin URL</th>
                    <td>
                        <input type="text" name="custom_admin_url" value="<?php echo esc_attr(get_option('custom_admin_url', '/custom-admin-login')); ?>" />
                        <p class="description">Enter the custom admin URL. Default is "/custom-admin-login".</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Redirect to the custom admin URL.
function custom_admin_url_redirector() {
    $custom_admin_url = get_option('custom_admin_url', '/custom-admin-login');

    // Check if the current request is for wp-login.php.

  
    if (strpos($_SERVER['REQUEST_URI'], $custom_admin_url) !== false) {
        require ABSPATH . 'wp-login.php';
        exit();
    }
}
add_action('init', 'custom_admin_url_redirector');

// Update the login URL based on the custom setting.
function custom_login_url_updater_filter($login_url, $redirect, $force_reauth) {
    $custom_login_url = get_option('custom_admin_url', '/custom-admin-login');
    return home_url('/404');
}
add_filter('login_url', 'custom_login_url_updater_filter', 10, 3);